<?php
session_start();
if(!isset($_SESSION['userId']))
{
  header('location:login.php');
}


include('sid.php');
 ?>
<?php //require "assets/function.php" ;




?>
<?php require 'assets/db.php';?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title><?php echo siteTitle(); ?></title>
  <?php require "assets/autoloader.php" ?>
  <style type="text/css">
  <?php include 'css/customStyle.css'; 
  include 'css/bootstrap.min.css';
  ?>

  </style>
  <?php 
  $notice="";
  if (isset($_POST['safeIn'])) 
  {
    $filename = $_FILES['inPic']['name'];
    move_uploaded_file($_FILES["inPic"]["tmp_name"], "photo/".$_FILES["inPic"]["name"]);
    if ($con->query("insert into categories (name,pic) value ('$_POST[name]','$filename')")) {
      $notice ="<div class='alert alert-success'>Successfully Saved</div>";
    }
    else
      $notice ="<div class='alert alert-danger'>Not saved Error:".$con->error."</div>";
  }

   ?>

<link rel="stylesheet" href="css/bootstrap.min.css"/>


<link rel="stylesheet" href="css/bootstrap.css" >

</head>
  <div class="row" style="width:90%;margin-right:5%">
    <?php echo $notice; ?>
    <div>
    
      <span style="font-size: 16pt;color: #333333">التصنيفات </span>
      <a href="manageCat.php"><button class="btn btn-primary btn-sm pull-right" data-toggle="modal" data-target="#addIn"><i class="fa fa-gear  fa-fw"> </i>ادارة التصنيفات</button></a>

    </div>

  <?php 
    $array = $con->query("select * from categories");
    while ($row = $array->fetch_array()) 
    {
      $array2 = $con->query("select count(*) from inventeries where catId = '$row[id]'");
      $row2 = $array2->fetch_assoc();
  ?>
    <a href="inventeries.php?catId=<?php echo $row['id'] ?>"><div class="col-sm-5">
     <div class=""> <img src="photo/<?php echo $row['pic'] ?>" style="height: 122px;" class='img-thumbnail'></div>
      <hr style="margin: 7px;">
      <span style="padding: 11px"><span  style="color:blue;margin-right: 11px;"><?php echo $row['name'] ?></span><strong style="font-size: 10pt;float:right" class="pull-right">الاسم</strong></span>
      <hr style="margin: 7px;">
      <span style="padding: 11px"><span style="color:blue;margin-right: 11px"><?php echo $row2['count(*)']; ?></span>  <strong class="pull-right" style="font-size: 10pt">الادوية المتوفرة</strong></span>
    </div></a>
  <?php
    }
   ?>
  </div>
</div></div>

<div id="addIn" class="modal fade" role="dialog">
  <div class="modal-dialog">

    
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">اضافة تصنيف جديد</h4>
      </div>
      <div class="modal-body"> <form method="POST" enctype="multipart/form-data">
        <div style="width: 77%;margin: auto;">
         
          <div class="form-group">
            <label for="some" class="col-form-label">الاسم</label>
            <input type="text" name="inName" class="form-control" id="some" required>
          </div>
          <div class="form-group">
            <label for="2" class="col-form-label">الصورة</label>
            <input type="file" name="inPic" class="form-control" id="2" required>
          </div>
          
       
        </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">الغاء</button>
        <button type="submit" class="btn btn-primary" name="safeIn">حفظ</button>
      </div>
     
    </form>
    </div>

  </div>
</div>

</body>
</html>

<script type="text/javascript">
  $(document).ready(function(){$(".rightAccount").click(function(){$(".account").fadeToggle();});});
</script>

